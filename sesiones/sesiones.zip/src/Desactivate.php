<?php
namespace RDCFTF;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
